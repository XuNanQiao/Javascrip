//Generate transition CSS (transition=0 to 14)
document.write('<STYLE TYPE="text/css">.imgTrans{ filter:revealTrans(duration=0.2,transition=14) }</STYLE>');

//Uncomment the next line for fading rollovers instead of dissolving:
//document.write('<STYLE TYPE="text/css">.imgTrans{ filter:blendTrans(duration=0.2) }</STYLE>');

var onImages=new Array();
function Rollover(imgName, imgSrc)
{
	onImages[imgName] = new Image();
	onImages[imgName].src = imgSrc;
}

function turnOn(imgName){
var ua=navigator.userAgent;
     var IEversion=parseFloat(ua.substring(ua.indexOf("MSIE")+5,ua.indexOf(";",ua.indexOf("MSIE"))));
if(document.images[imgName].filters != null)
document.images[imgName].filters[0].apply();
document.images[imgName].offSrc = document.images[imgName].src;
document.images[imgName].src    = onImages[imgName].src;
if(document.images[imgName].filters != null){
if(IEversion == 6.0)
document.images[imgName].filters[0].apply();
else
document.images[imgName].filters[0].play();}
}


function turnOff(imgName){ 
	if(document.images[imgName].filters != null)
		document.images[imgName].filters[0].stop();
	document.images[imgName].src = document.images[imgName].offSrc;
}

//Specify name of participating images, plus paths to their onMouseover replacements:
Rollover("ab",  "images/about_1.gif");
Rollover("va",  "images/view_1.gif");
Rollover("po",  "images/portfolio_1.gif");
Rollover("se",  "images/services_1.gif");
Rollover("in",  "images/index_1.gif");
Rollover("en",  "images/blog_1.gif");
Rollover("co",  "images/contact_1.gif");
